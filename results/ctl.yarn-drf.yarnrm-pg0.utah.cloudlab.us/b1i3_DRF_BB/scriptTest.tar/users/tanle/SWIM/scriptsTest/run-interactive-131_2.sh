cd ~/ 
~/hadoop/bin/hadoop jar ~/hadoop/tez_jars/tez-examples-0.8.4.jar dumpjob  1131 bursty2 >> ~/SWIM/scriptsTest/workGenLogs/interactive-131_2.txt 2>> ~/SWIM/scriptsTest/workGenLogs/interactive-131_2.txt  &  interactive131="$interactive131 $!"  
wait $interactive131 
