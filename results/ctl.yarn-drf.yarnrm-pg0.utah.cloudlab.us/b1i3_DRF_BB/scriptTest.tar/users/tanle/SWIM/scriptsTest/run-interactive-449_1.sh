cd ~/ 
~/hadoop/bin/hadoop jar ~/hadoop/tez_jars/tez-examples-0.8.4.jar dumpjob  949 bursty1 >> ~/SWIM/scriptsTest/workGenLogs/interactive-449_1.txt 2>> ~/SWIM/scriptsTest/workGenLogs/interactive-449_1.txt  &  interactive449="$interactive449 $!"  
wait $interactive449 
