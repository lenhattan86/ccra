cd ~/ 
~/hadoop/bin/hadoop jar ~/hadoop/tez_jars/tez-examples-0.8.4.jar dumpjob  250 bursty0 >> ~/SWIM/scriptsTest/workGenLogs/interactive-250_0.txt 2>> ~/SWIM/scriptsTest/workGenLogs/interactive-250_0.txt  &  interactive250="$interactive250 $!"  
wait $interactive250 
