cd ~/ 
~/hadoop/bin/hadoop jar ~/hadoop/tez_jars/tez-examples-0.8.4.jar dumpjob  347 bursty0 >> ~/SWIM/scriptsTest/workGenLogs/interactive-347_0.txt 2>> ~/SWIM/scriptsTest/workGenLogs/interactive-347_0.txt  &  interactive347="$interactive347 $!"  
wait $interactive347 
