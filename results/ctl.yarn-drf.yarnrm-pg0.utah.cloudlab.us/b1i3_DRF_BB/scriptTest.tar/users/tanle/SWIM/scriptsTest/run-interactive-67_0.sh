cd ~/ 
~/hadoop/bin/hadoop jar ~/hadoop/tez_jars/tez-examples-0.8.4.jar dumpjob  67 bursty0 >> ~/SWIM/scriptsTest/workGenLogs/interactive-67_0.txt 2>> ~/SWIM/scriptsTest/workGenLogs/interactive-67_0.txt  &  interactive67="$interactive67 $!"  
wait $interactive67 
