cd ~/ 
~/hadoop/bin/hadoop jar ~/hadoop/tez_jars/tez-examples-0.8.4.jar dumpjob  1348 bursty2 >> ~/SWIM/scriptsTest/workGenLogs/interactive-348_2.txt 2>> ~/SWIM/scriptsTest/workGenLogs/interactive-348_2.txt  &  interactive348="$interactive348 $!"  
wait $interactive348 
