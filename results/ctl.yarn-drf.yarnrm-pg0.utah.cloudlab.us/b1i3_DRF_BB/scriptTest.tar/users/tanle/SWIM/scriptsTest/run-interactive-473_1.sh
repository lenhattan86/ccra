cd ~/ 
~/hadoop/bin/hadoop jar ~/hadoop/tez_jars/tez-examples-0.8.4.jar dumpjob  973 bursty1 >> ~/SWIM/scriptsTest/workGenLogs/interactive-473_1.txt 2>> ~/SWIM/scriptsTest/workGenLogs/interactive-473_1.txt  &  interactive473="$interactive473 $!"  
wait $interactive473 
