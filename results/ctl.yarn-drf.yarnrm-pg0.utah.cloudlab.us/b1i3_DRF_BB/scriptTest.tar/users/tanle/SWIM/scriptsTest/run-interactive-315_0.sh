cd ~/ 
~/hadoop/bin/hadoop jar ~/hadoop/tez_jars/tez-examples-0.8.4.jar dumpjob  315 bursty0 >> ~/SWIM/scriptsTest/workGenLogs/interactive-315_0.txt 2>> ~/SWIM/scriptsTest/workGenLogs/interactive-315_0.txt  &  interactive315="$interactive315 $!"  
wait $interactive315 
