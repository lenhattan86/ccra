cd ~/ 
~/hadoop/bin/hadoop jar ~/hadoop/tez_jars/tez-examples-0.8.4.jar dumpjob  1255 bursty2 >> ~/SWIM/scriptsTest/workGenLogs/interactive-255_2.txt 2>> ~/SWIM/scriptsTest/workGenLogs/interactive-255_2.txt  &  interactive255="$interactive255 $!"  
wait $interactive255 
