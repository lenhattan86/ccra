cd ~/ 
~/hadoop/bin/hadoop jar ~/hadoop/tez_jars/tez-examples-0.8.4.jar dumpjob  1446 bursty2 >> ~/SWIM/scriptsTest/workGenLogs/interactive-446_2.txt 2>> ~/SWIM/scriptsTest/workGenLogs/interactive-446_2.txt  &  interactive446="$interactive446 $!"  
wait $interactive446 
