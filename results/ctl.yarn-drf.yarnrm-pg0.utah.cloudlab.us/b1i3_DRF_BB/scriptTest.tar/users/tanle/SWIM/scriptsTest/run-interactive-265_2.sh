cd ~/ 
~/hadoop/bin/hadoop jar ~/hadoop/tez_jars/tez-examples-0.8.4.jar dumpjob  1265 bursty2 >> ~/SWIM/scriptsTest/workGenLogs/interactive-265_2.txt 2>> ~/SWIM/scriptsTest/workGenLogs/interactive-265_2.txt  &  interactive265="$interactive265 $!"  
wait $interactive265 
