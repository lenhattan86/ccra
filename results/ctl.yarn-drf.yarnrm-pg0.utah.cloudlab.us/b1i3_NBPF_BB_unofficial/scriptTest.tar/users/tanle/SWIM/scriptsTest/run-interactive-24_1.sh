cd ~/ 
~/hadoop/bin/hadoop jar ~/hadoop/tez_jars/tez-examples-0.8.4.jar dumpjob  54 bursty1 >> ~/SWIM/scriptsTest/workGenLogs/interactive-24_1.txt 2>> ~/SWIM/scriptsTest/workGenLogs/interactive-24_1.txt  &  interactive24="$interactive24 $!"  
wait $interactive24 
