cd ~/ 
~/hadoop/bin/hadoop jar ~/hadoop/tez_jars/tez-examples-0.8.4.jar dumpjob  86 bursty2 >> ~/SWIM/scriptsTest/workGenLogs/interactive-26_2.txt 2>> ~/SWIM/scriptsTest/workGenLogs/interactive-26_2.txt  &  interactive26="$interactive26 $!"  
wait $interactive26 
