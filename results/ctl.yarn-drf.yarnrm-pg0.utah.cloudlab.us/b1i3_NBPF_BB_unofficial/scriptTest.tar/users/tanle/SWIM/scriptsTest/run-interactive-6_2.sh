cd ~/ 
~/hadoop/bin/hadoop jar ~/hadoop/tez_jars/tez-examples-0.8.4.jar dumpjob  66 bursty2 >> ~/SWIM/scriptsTest/workGenLogs/interactive-6_2.txt 2>> ~/SWIM/scriptsTest/workGenLogs/interactive-6_2.txt  &  interactive6="$interactive6 $!"  
wait $interactive6 
