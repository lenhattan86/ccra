#!/bin/bash
mkdir ~/SWIM/scriptsTest/workGenLogs
./run-batch-0.sh &
./run-batch-1.sh &
./run-batch-2.sh &
./run-batch-3.sh &
./run-batch-4.sh &
./run-batch-5.sh &
./run-batch-6.sh &
./run-batch-7.sh &
sleep 160 
./run-batch-8.sh &
./run-batch-9.sh &
./run-batch-10.sh &
./run-batch-11.sh &
./run-batch-12.sh &
./run-batch-13.sh &
./run-batch-14.sh &
./run-batch-15.sh &
sleep 160 
./run-batch-16.sh &
./run-batch-17.sh &
./run-batch-18.sh &
./run-batch-19.sh &

 wait