#!/bin/bash
mkdir ~/SWIM/scriptsTest/workGenLogs
sleep 350
./run-interactive-0_2.sh &
sleep 60
serverList="ctl  cp-1 cp-2 cp-3 cp-4 cp-5 cp-6 cp-7 cp-8 cp-9 cp-10 cp-11 cp-12 cp-13 cp-14 cp-15 cp-16 cp-17 cp-18 cp-19 cp-20 cp-21 cp-22 cp-23 cp-24 cp-25 cp-26 cp-27 cp-28 cp-29 cp-30 cp-31 cp-32 cp-33 cp-34 cp-35 cp-36 cp-37 cp-38 cp-39 cp-40" 
for server in $serverList; do  
    ssh $server "sudo rm -rf /dev/yarn-logs/* " & 
done 
 
./run-interactive-1_2.sh &
sleep 60
serverList="ctl  cp-1 cp-2 cp-3 cp-4 cp-5 cp-6 cp-7 cp-8 cp-9 cp-10 cp-11 cp-12 cp-13 cp-14 cp-15 cp-16 cp-17 cp-18 cp-19 cp-20 cp-21 cp-22 cp-23 cp-24 cp-25 cp-26 cp-27 cp-28 cp-29 cp-30 cp-31 cp-32 cp-33 cp-34 cp-35 cp-36 cp-37 cp-38 cp-39 cp-40" 
for server in $serverList; do  
    ssh $server "sudo rm -rf /dev/yarn-logs/* " & 
done 
 
./run-interactive-2_2.sh &
sleep 60
serverList="ctl  cp-1 cp-2 cp-3 cp-4 cp-5 cp-6 cp-7 cp-8 cp-9 cp-10 cp-11 cp-12 cp-13 cp-14 cp-15 cp-16 cp-17 cp-18 cp-19 cp-20 cp-21 cp-22 cp-23 cp-24 cp-25 cp-26 cp-27 cp-28 cp-29 cp-30 cp-31 cp-32 cp-33 cp-34 cp-35 cp-36 cp-37 cp-38 cp-39 cp-40" 
for server in $serverList; do  
    ssh $server "sudo rm -rf /dev/yarn-logs/* " & 
done 
 
./run-interactive-3_2.sh &
sleep 60
serverList="ctl  cp-1 cp-2 cp-3 cp-4 cp-5 cp-6 cp-7 cp-8 cp-9 cp-10 cp-11 cp-12 cp-13 cp-14 cp-15 cp-16 cp-17 cp-18 cp-19 cp-20 cp-21 cp-22 cp-23 cp-24 cp-25 cp-26 cp-27 cp-28 cp-29 cp-30 cp-31 cp-32 cp-33 cp-34 cp-35 cp-36 cp-37 cp-38 cp-39 cp-40" 
for server in $serverList; do  
    ssh $server "sudo rm -rf /dev/yarn-logs/* " & 
done 
 
./run-interactive-4_2.sh &
sleep 60
serverList="ctl  cp-1 cp-2 cp-3 cp-4 cp-5 cp-6 cp-7 cp-8 cp-9 cp-10 cp-11 cp-12 cp-13 cp-14 cp-15 cp-16 cp-17 cp-18 cp-19 cp-20 cp-21 cp-22 cp-23 cp-24 cp-25 cp-26 cp-27 cp-28 cp-29 cp-30 cp-31 cp-32 cp-33 cp-34 cp-35 cp-36 cp-37 cp-38 cp-39 cp-40" 
for server in $serverList; do  
    ssh $server "sudo rm -rf /dev/yarn-logs/* " & 
done 
 
./run-interactive-5_2.sh &
sleep 60
serverList="ctl  cp-1 cp-2 cp-3 cp-4 cp-5 cp-6 cp-7 cp-8 cp-9 cp-10 cp-11 cp-12 cp-13 cp-14 cp-15 cp-16 cp-17 cp-18 cp-19 cp-20 cp-21 cp-22 cp-23 cp-24 cp-25 cp-26 cp-27 cp-28 cp-29 cp-30 cp-31 cp-32 cp-33 cp-34 cp-35 cp-36 cp-37 cp-38 cp-39 cp-40" 
for server in $serverList; do  
    ssh $server "sudo rm -rf /dev/yarn-logs/* " & 
done 
 
./run-interactive-6_2.sh &
sleep 60
serverList="ctl  cp-1 cp-2 cp-3 cp-4 cp-5 cp-6 cp-7 cp-8 cp-9 cp-10 cp-11 cp-12 cp-13 cp-14 cp-15 cp-16 cp-17 cp-18 cp-19 cp-20 cp-21 cp-22 cp-23 cp-24 cp-25 cp-26 cp-27 cp-28 cp-29 cp-30 cp-31 cp-32 cp-33 cp-34 cp-35 cp-36 cp-37 cp-38 cp-39 cp-40" 
for server in $serverList; do  
    ssh $server "sudo rm -rf /dev/yarn-logs/* " & 
done 
 
./run-interactive-7_2.sh &
sleep 60
serverList="ctl  cp-1 cp-2 cp-3 cp-4 cp-5 cp-6 cp-7 cp-8 cp-9 cp-10 cp-11 cp-12 cp-13 cp-14 cp-15 cp-16 cp-17 cp-18 cp-19 cp-20 cp-21 cp-22 cp-23 cp-24 cp-25 cp-26 cp-27 cp-28 cp-29 cp-30 cp-31 cp-32 cp-33 cp-34 cp-35 cp-36 cp-37 cp-38 cp-39 cp-40" 
for server in $serverList; do  
    ssh $server "sudo rm -rf /dev/yarn-logs/* " & 
done 
 
./run-interactive-8_2.sh &
sleep 60
serverList="ctl  cp-1 cp-2 cp-3 cp-4 cp-5 cp-6 cp-7 cp-8 cp-9 cp-10 cp-11 cp-12 cp-13 cp-14 cp-15 cp-16 cp-17 cp-18 cp-19 cp-20 cp-21 cp-22 cp-23 cp-24 cp-25 cp-26 cp-27 cp-28 cp-29 cp-30 cp-31 cp-32 cp-33 cp-34 cp-35 cp-36 cp-37 cp-38 cp-39 cp-40" 
for server in $serverList; do  
    ssh $server "sudo rm -rf /dev/yarn-logs/* " & 
done 
 
./run-interactive-9_2.sh &
lastInteractive=$! ; 
 wait $lastInteractive 60
