cd ~/ 
~/hadoop/bin/hadoop jar ~/hadoop/tez_jars/tez-examples-0.8.4.jar dumpjob  653 bursty1 >> ~/SWIM/scriptsTest/workGenLogs/interactive-153_1.txt 2>> ~/SWIM/scriptsTest/workGenLogs/interactive-153_1.txt  &  interactive153="$interactive153 $!"  
wait $interactive153 
