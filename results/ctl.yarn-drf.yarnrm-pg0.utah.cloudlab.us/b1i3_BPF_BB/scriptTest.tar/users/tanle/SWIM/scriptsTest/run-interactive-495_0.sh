cd ~/ 
~/hadoop/bin/hadoop jar ~/hadoop/tez_jars/tez-examples-0.8.4.jar dumpjob  495 bursty0 >> ~/SWIM/scriptsTest/workGenLogs/interactive-495_0.txt 2>> ~/SWIM/scriptsTest/workGenLogs/interactive-495_0.txt  &  interactive495="$interactive495 $!"  
wait $interactive495 
