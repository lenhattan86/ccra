cd ~/ 
~/hadoop/bin/hadoop jar ~/hadoop/tez_jars/tez-examples-0.8.4.jar dumpjob  1349 bursty2 >> ~/SWIM/scriptsTest/workGenLogs/interactive-349_2.txt 2>> ~/SWIM/scriptsTest/workGenLogs/interactive-349_2.txt  &  interactive349="$interactive349 $!"  
wait $interactive349 
