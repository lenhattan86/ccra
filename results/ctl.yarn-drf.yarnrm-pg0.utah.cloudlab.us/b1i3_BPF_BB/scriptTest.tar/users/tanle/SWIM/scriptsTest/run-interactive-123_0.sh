cd ~/ 
~/hadoop/bin/hadoop jar ~/hadoop/tez_jars/tez-examples-0.8.4.jar dumpjob  123 bursty0 >> ~/SWIM/scriptsTest/workGenLogs/interactive-123_0.txt 2>> ~/SWIM/scriptsTest/workGenLogs/interactive-123_0.txt  &  interactive123="$interactive123 $!"  
wait $interactive123 
