cd ~/ 
~/hadoop/bin/hadoop jar ~/hadoop/tez_jars/tez-examples-0.8.4.jar dumpjob  489 bursty0 >> ~/SWIM/scriptsTest/workGenLogs/interactive-489_0.txt 2>> ~/SWIM/scriptsTest/workGenLogs/interactive-489_0.txt  &  interactive489="$interactive489 $!"  
wait $interactive489 
