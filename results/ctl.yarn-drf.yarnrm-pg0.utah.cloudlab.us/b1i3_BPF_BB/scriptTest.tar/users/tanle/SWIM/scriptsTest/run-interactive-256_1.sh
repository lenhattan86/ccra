cd ~/ 
~/hadoop/bin/hadoop jar ~/hadoop/tez_jars/tez-examples-0.8.4.jar dumpjob  756 bursty1 >> ~/SWIM/scriptsTest/workGenLogs/interactive-256_1.txt 2>> ~/SWIM/scriptsTest/workGenLogs/interactive-256_1.txt  &  interactive256="$interactive256 $!"  
wait $interactive256 
