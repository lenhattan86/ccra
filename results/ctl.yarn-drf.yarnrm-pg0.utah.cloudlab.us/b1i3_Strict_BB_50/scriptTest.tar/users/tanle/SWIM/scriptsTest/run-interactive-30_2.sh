cd ~/ 
~/hadoop/bin/hadoop jar ~/hadoop/tez_jars/tez-examples-0.8.4.jar dumpjob  130 bursty2 >> ~/SWIM/scriptsTest/workGenLogs/interactive-30_2.txt 2>> ~/SWIM/scriptsTest/workGenLogs/interactive-30_2.txt  &  interactive30="$interactive30 $!"  
wait $interactive30 
