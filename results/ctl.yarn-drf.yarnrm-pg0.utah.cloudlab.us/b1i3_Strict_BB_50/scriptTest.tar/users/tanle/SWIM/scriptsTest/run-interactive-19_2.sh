cd ~/ 
~/hadoop/bin/hadoop jar ~/hadoop/tez_jars/tez-examples-0.8.4.jar dumpjob  119 bursty2 >> ~/SWIM/scriptsTest/workGenLogs/interactive-19_2.txt 2>> ~/SWIM/scriptsTest/workGenLogs/interactive-19_2.txt  &  interactive19="$interactive19 $!"  
wait $interactive19 
