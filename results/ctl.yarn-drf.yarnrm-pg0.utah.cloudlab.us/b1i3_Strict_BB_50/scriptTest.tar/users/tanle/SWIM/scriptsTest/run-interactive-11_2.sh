cd ~/ 
~/hadoop/bin/hadoop jar ~/hadoop/tez_jars/tez-examples-0.8.4.jar dumpjob  111 bursty2 >> ~/SWIM/scriptsTest/workGenLogs/interactive-11_2.txt 2>> ~/SWIM/scriptsTest/workGenLogs/interactive-11_2.txt  &  interactive11="$interactive11 $!"  
wait $interactive11 
