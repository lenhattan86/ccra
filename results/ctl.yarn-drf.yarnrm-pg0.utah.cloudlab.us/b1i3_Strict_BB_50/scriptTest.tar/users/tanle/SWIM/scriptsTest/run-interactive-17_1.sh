cd ~/ 
~/hadoop/bin/hadoop jar ~/hadoop/tez_jars/tez-examples-0.8.4.jar dumpjob  67 bursty1 >> ~/SWIM/scriptsTest/workGenLogs/interactive-17_1.txt 2>> ~/SWIM/scriptsTest/workGenLogs/interactive-17_1.txt  &  interactive17="$interactive17 $!"  
wait $interactive17 
