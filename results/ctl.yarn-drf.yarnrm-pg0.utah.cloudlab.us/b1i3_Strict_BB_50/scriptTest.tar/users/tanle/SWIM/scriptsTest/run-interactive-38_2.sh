cd ~/ 
~/hadoop/bin/hadoop jar ~/hadoop/tez_jars/tez-examples-0.8.4.jar dumpjob  138 bursty2 >> ~/SWIM/scriptsTest/workGenLogs/interactive-38_2.txt 2>> ~/SWIM/scriptsTest/workGenLogs/interactive-38_2.txt  &  interactive38="$interactive38 $!"  
wait $interactive38 
