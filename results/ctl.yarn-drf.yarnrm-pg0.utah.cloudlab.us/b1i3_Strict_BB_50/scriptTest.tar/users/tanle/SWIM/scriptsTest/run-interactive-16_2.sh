cd ~/ 
~/hadoop/bin/hadoop jar ~/hadoop/tez_jars/tez-examples-0.8.4.jar dumpjob  116 bursty2 >> ~/SWIM/scriptsTest/workGenLogs/interactive-16_2.txt 2>> ~/SWIM/scriptsTest/workGenLogs/interactive-16_2.txt  &  interactive16="$interactive16 $!"  
wait $interactive16 
