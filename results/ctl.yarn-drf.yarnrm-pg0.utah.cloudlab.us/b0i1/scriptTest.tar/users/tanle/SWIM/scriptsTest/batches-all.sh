#!/bin/bash
mkdir ~/SWIM/scriptsTest/workGenLogs

 wait