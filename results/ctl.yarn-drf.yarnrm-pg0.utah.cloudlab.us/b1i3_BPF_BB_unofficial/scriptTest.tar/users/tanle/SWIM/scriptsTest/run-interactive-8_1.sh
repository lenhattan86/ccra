cd ~/ 
~/hadoop/bin/hadoop jar ~/hadoop/tez_jars/tez-examples-0.8.4.jar dumpjob  38 bursty1 >> ~/SWIM/scriptsTest/workGenLogs/interactive-8_1.txt 2>> ~/SWIM/scriptsTest/workGenLogs/interactive-8_1.txt  &  interactive8="$interactive8 $!"  
wait $interactive8 
