cd ~/ 
~/hadoop/bin/hadoop jar ~/hadoop/tez_jars/tez-examples-0.8.4.jar dumpjob  1381 bursty2 >> ~/SWIM/scriptsTest/workGenLogs/interactive-381_2.txt 2>> ~/SWIM/scriptsTest/workGenLogs/interactive-381_2.txt  &  interactive381="$interactive381 $!"  
wait $interactive381 
