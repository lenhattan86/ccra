cd ~/ 
~/hadoop/bin/hadoop jar ~/hadoop/tez_jars/tez-examples-0.8.4.jar dumpjob  113 bursty0 >> ~/SWIM/scriptsTest/workGenLogs/interactive-113_0.txt 2>> ~/SWIM/scriptsTest/workGenLogs/interactive-113_0.txt  &  interactive113="$interactive113 $!"  
wait $interactive113 
