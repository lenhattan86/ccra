cd ~/ 
~/hadoop/bin/hadoop jar ~/hadoop/tez_jars/tez-examples-0.8.4.jar dumpjob  1128 bursty2 >> ~/SWIM/scriptsTest/workGenLogs/interactive-128_2.txt 2>> ~/SWIM/scriptsTest/workGenLogs/interactive-128_2.txt  &  interactive128="$interactive128 $!"  
wait $interactive128 
