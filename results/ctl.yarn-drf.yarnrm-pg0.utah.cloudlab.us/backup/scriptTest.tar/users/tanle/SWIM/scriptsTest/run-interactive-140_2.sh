cd ~/ 
~/hadoop/bin/hadoop jar ~/hadoop/tez_jars/tez-examples-0.8.4.jar dumpjob  1140 bursty2 >> ~/SWIM/scriptsTest/workGenLogs/interactive-140_2.txt 2>> ~/SWIM/scriptsTest/workGenLogs/interactive-140_2.txt  &  interactive140="$interactive140 $!"  
wait $interactive140 
