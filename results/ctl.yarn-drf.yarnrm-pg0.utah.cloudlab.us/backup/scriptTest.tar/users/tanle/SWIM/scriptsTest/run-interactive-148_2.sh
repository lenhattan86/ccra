cd ~/ 
~/hadoop/bin/hadoop jar ~/hadoop/tez_jars/tez-examples-0.8.4.jar dumpjob  1148 bursty2 >> ~/SWIM/scriptsTest/workGenLogs/interactive-148_2.txt 2>> ~/SWIM/scriptsTest/workGenLogs/interactive-148_2.txt  &  interactive148="$interactive148 $!"  
wait $interactive148 
