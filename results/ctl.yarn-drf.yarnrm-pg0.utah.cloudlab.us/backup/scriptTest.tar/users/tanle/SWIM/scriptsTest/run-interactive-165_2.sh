cd ~/ 
~/hadoop/bin/hadoop jar ~/hadoop/tez_jars/tez-examples-0.8.4.jar dumpjob  1165 bursty2 >> ~/SWIM/scriptsTest/workGenLogs/interactive-165_2.txt 2>> ~/SWIM/scriptsTest/workGenLogs/interactive-165_2.txt  &  interactive165="$interactive165 $!"  
wait $interactive165 
