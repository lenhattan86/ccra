cd ~/ 
~/hadoop/bin/hadoop jar ~/hadoop/tez_jars/tez-examples-0.8.4.jar dumpjob  1324 bursty2 >> ~/SWIM/scriptsTest/workGenLogs/interactive-324_2.txt 2>> ~/SWIM/scriptsTest/workGenLogs/interactive-324_2.txt  &  interactive324="$interactive324 $!"  
wait $interactive324 
