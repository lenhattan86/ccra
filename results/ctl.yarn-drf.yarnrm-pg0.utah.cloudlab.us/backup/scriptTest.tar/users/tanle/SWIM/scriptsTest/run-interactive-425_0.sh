cd ~/ 
~/hadoop/bin/hadoop jar ~/hadoop/tez_jars/tez-examples-0.8.4.jar dumpjob  425 bursty0 >> ~/SWIM/scriptsTest/workGenLogs/interactive-425_0.txt 2>> ~/SWIM/scriptsTest/workGenLogs/interactive-425_0.txt  &  interactive425="$interactive425 $!"  
wait $interactive425 
