cd ~/ 
~/hadoop/bin/hadoop jar ~/hadoop/tez_jars/tez-examples-0.8.4.jar dumpjob  1478 bursty2 >> ~/SWIM/scriptsTest/workGenLogs/interactive-478_2.txt 2>> ~/SWIM/scriptsTest/workGenLogs/interactive-478_2.txt  &  interactive478="$interactive478 $!"  
wait $interactive478 
