cd ~/ 
~/hadoop/bin/hadoop jar ~/hadoop/tez_jars/tez-examples-0.8.4.jar dumpjob  359 bursty0 >> ~/SWIM/scriptsTest/workGenLogs/interactive-359_0.txt 2>> ~/SWIM/scriptsTest/workGenLogs/interactive-359_0.txt  &  interactive359="$interactive359 $!"  
wait $interactive359 
