cd ~/ 
~/hadoop/bin/hadoop jar ~/hadoop/tez_jars/tez-examples-0.8.4.jar dumpjob  107 bursty0 >> ~/SWIM/scriptsTest/workGenLogs/interactive-107_0.txt 2>> ~/SWIM/scriptsTest/workGenLogs/interactive-107_0.txt  &  interactive107="$interactive107 $!"  
wait $interactive107 
