cd ~/ 
~/hadoop/bin/hadoop jar ~/hadoop/tez_jars/tez-examples-0.8.4.jar dumpjob  293 bursty0 >> ~/SWIM/scriptsTest/workGenLogs/interactive-293_0.txt 2>> ~/SWIM/scriptsTest/workGenLogs/interactive-293_0.txt  &  interactive293="$interactive293 $!"  
wait $interactive293 
