cd ~/ 
~/hadoop/bin/hadoop jar ~/hadoop/tez_jars/tez-examples-0.8.4.jar dumpjob  1097 bursty2 >> ~/SWIM/scriptsTest/workGenLogs/interactive-97_2.txt 2>> ~/SWIM/scriptsTest/workGenLogs/interactive-97_2.txt  &  interactive97="$interactive97 $!"  
wait $interactive97 
