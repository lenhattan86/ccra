cd ~/ 
~/hadoop/bin/hadoop jar ~/hadoop/tez_jars/tez-examples-0.8.4.jar dumpjob  1111 bursty2 >> ~/SWIM/scriptsTest/workGenLogs/interactive-111_2.txt 2>> ~/SWIM/scriptsTest/workGenLogs/interactive-111_2.txt  &  interactive111="$interactive111 $!"  
wait $interactive111 
