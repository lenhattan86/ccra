cd ~/ 
~/hadoop/bin/hadoop jar ~/hadoop/tez_jars/tez-examples-0.8.4.jar dumpjob  112 bursty1 >> ~/SWIM/scriptsTest/workGenLogs/interactive-12_1.txt 2>> ~/SWIM/scriptsTest/workGenLogs/interactive-12_1.txt  &  interactive12="$interactive12 $!"  
wait $interactive12 
