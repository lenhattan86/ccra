cd ~/ 
~/hadoop/bin/hadoop jar ~/hadoop/tez_jars/tez-examples-0.8.4.jar dumpjob  263 bursty2 >> ~/SWIM/scriptsTest/workGenLogs/interactive-63_2.txt 2>> ~/SWIM/scriptsTest/workGenLogs/interactive-63_2.txt  &  interactive63="$interactive63 $!"  
wait $interactive63 
