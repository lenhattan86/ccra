cd ~/ 
~/hadoop/bin/hadoop jar ~/hadoop/tez_jars/tez-examples-0.8.4.jar dumpjob  168 bursty1 >> ~/SWIM/scriptsTest/workGenLogs/interactive-68_1.txt 2>> ~/SWIM/scriptsTest/workGenLogs/interactive-68_1.txt  &  interactive68="$interactive68 $!"  
wait $interactive68 
