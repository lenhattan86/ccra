cd ~/ 
~/hadoop/bin/hadoop jar ~/hadoop/tez_jars/tez-examples-0.8.4.jar dumpjob  138 bursty1 >> ~/SWIM/scriptsTest/workGenLogs/interactive-38_1.txt 2>> ~/SWIM/scriptsTest/workGenLogs/interactive-38_1.txt  &  interactive38="$interactive38 $!"  
wait $interactive38 
