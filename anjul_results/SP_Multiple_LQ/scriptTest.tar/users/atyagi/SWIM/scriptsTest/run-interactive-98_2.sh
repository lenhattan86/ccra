cd ~/ 
~/hadoop/bin/hadoop jar ~/hadoop/tez_jars/tez-examples-0.8.4.jar dumpjob  298 bursty2 >> ~/SWIM/scriptsTest/workGenLogs/interactive-98_2.txt 2>> ~/SWIM/scriptsTest/workGenLogs/interactive-98_2.txt  &  interactive98="$interactive98 $!"  
wait $interactive98 
