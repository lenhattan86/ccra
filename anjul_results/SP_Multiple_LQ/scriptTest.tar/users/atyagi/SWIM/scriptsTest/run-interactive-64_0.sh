cd ~/ 
~/hadoop/bin/hadoop jar ~/hadoop/tez_jars/tez-examples-0.8.4.jar dumpjob  64 bursty0 >> ~/SWIM/scriptsTest/workGenLogs/interactive-64_0.txt 2>> ~/SWIM/scriptsTest/workGenLogs/interactive-64_0.txt  &  interactive64="$interactive64 $!"  
wait $interactive64 
