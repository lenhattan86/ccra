cd ~/ 
~/hadoop/bin/hadoop jar ~/hadoop/tez_jars/tez-examples-0.8.4.jar dumpjob  268 bursty2 >> ~/SWIM/scriptsTest/workGenLogs/interactive-68_2.txt 2>> ~/SWIM/scriptsTest/workGenLogs/interactive-68_2.txt  &  interactive68="$interactive68 $!"  
wait $interactive68 
