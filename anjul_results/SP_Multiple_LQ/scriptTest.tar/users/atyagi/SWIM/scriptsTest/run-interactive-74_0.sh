cd ~/ 
~/hadoop/bin/hadoop jar ~/hadoop/tez_jars/tez-examples-0.8.4.jar dumpjob  74 bursty0 >> ~/SWIM/scriptsTest/workGenLogs/interactive-74_0.txt 2>> ~/SWIM/scriptsTest/workGenLogs/interactive-74_0.txt  &  interactive74="$interactive74 $!"  
wait $interactive74 
