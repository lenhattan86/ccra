cd ~/ 
~/hadoop/bin/hadoop jar ~/hadoop/tez_jars/tez-examples-0.8.4.jar dumpjob  199 bursty1 >> ~/SWIM/scriptsTest/workGenLogs/interactive-99_1.txt 2>> ~/SWIM/scriptsTest/workGenLogs/interactive-99_1.txt  &  interactive99="$interactive99 $!"  
wait $interactive99 
