cd ~/ 
~/hadoop/bin/hadoop jar ~/hadoop/tez_jars/tez-examples-0.8.4.jar dumpjob  276 bursty2 >> ~/SWIM/scriptsTest/workGenLogs/interactive-76_2.txt 2>> ~/SWIM/scriptsTest/workGenLogs/interactive-76_2.txt  &  interactive76="$interactive76 $!"  
wait $interactive76 
