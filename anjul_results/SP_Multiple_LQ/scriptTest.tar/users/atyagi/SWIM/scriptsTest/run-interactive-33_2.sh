cd ~/ 
~/hadoop/bin/hadoop jar ~/hadoop/tez_jars/tez-examples-0.8.4.jar dumpjob  233 bursty2 >> ~/SWIM/scriptsTest/workGenLogs/interactive-33_2.txt 2>> ~/SWIM/scriptsTest/workGenLogs/interactive-33_2.txt  &  interactive33="$interactive33 $!"  
wait $interactive33 
