cd ~/ 
~/hadoop/bin/hadoop jar ~/hadoop/tez_jars/tez-examples-0.8.4.jar dumpjob  236 bursty2 >> ~/SWIM/scriptsTest/workGenLogs/interactive-36_2.txt 2>> ~/SWIM/scriptsTest/workGenLogs/interactive-36_2.txt  &  interactive36="$interactive36 $!"  
wait $interactive36 
