cd ~/ 
~/hadoop/bin/hadoop jar ~/hadoop/tez_jars/tez-examples-0.8.4.jar dumpjob  82 bursty0 >> ~/SWIM/scriptsTest/workGenLogs/interactive-82_0.txt 2>> ~/SWIM/scriptsTest/workGenLogs/interactive-82_0.txt  &  interactive82="$interactive82 $!"  
wait $interactive82 
