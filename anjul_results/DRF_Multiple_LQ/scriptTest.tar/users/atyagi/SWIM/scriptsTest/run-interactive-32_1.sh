cd ~/ 
~/hadoop/bin/hadoop jar ~/hadoop/tez_jars/tez-examples-0.8.4.jar dumpjob  132 bursty1 >> ~/SWIM/scriptsTest/workGenLogs/interactive-32_1.txt 2>> ~/SWIM/scriptsTest/workGenLogs/interactive-32_1.txt  &  interactive32="$interactive32 $!"  
wait $interactive32 
