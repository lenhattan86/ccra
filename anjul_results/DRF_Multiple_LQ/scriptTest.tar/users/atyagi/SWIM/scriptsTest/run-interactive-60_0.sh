cd ~/ 
~/hadoop/bin/hadoop jar ~/hadoop/tez_jars/tez-examples-0.8.4.jar dumpjob  60 bursty0 >> ~/SWIM/scriptsTest/workGenLogs/interactive-60_0.txt 2>> ~/SWIM/scriptsTest/workGenLogs/interactive-60_0.txt  &  interactive60="$interactive60 $!"  
wait $interactive60 
