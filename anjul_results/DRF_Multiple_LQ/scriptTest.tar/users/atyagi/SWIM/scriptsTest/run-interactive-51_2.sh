cd ~/ 
~/hadoop/bin/hadoop jar ~/hadoop/tez_jars/tez-examples-0.8.4.jar dumpjob  251 bursty2 >> ~/SWIM/scriptsTest/workGenLogs/interactive-51_2.txt 2>> ~/SWIM/scriptsTest/workGenLogs/interactive-51_2.txt  &  interactive51="$interactive51 $!"  
wait $interactive51 
