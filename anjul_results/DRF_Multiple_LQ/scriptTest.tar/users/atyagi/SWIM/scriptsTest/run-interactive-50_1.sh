cd ~/ 
~/hadoop/bin/hadoop jar ~/hadoop/tez_jars/tez-examples-0.8.4.jar dumpjob  150 bursty1 >> ~/SWIM/scriptsTest/workGenLogs/interactive-50_1.txt 2>> ~/SWIM/scriptsTest/workGenLogs/interactive-50_1.txt  &  interactive50="$interactive50 $!"  
wait $interactive50 
