cd ~/ 
~/hadoop/bin/hadoop jar ~/hadoop/tez_jars/tez-examples-0.8.4.jar dumpjob  105 bursty1 >> ~/SWIM/scriptsTest/workGenLogs/interactive-5_1.txt 2>> ~/SWIM/scriptsTest/workGenLogs/interactive-5_1.txt  &  interactive5="$interactive5 $!"  
wait $interactive5 
