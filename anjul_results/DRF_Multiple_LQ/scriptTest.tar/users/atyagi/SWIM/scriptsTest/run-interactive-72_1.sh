cd ~/ 
~/hadoop/bin/hadoop jar ~/hadoop/tez_jars/tez-examples-0.8.4.jar dumpjob  172 bursty1 >> ~/SWIM/scriptsTest/workGenLogs/interactive-72_1.txt 2>> ~/SWIM/scriptsTest/workGenLogs/interactive-72_1.txt  &  interactive72="$interactive72 $!"  
wait $interactive72 
