cd ~/ 
~/hadoop/bin/hadoop jar ~/hadoop/tez_jars/tez-examples-0.8.4.jar dumpjob  197 bursty1 >> ~/SWIM/scriptsTest/workGenLogs/interactive-97_1.txt 2>> ~/SWIM/scriptsTest/workGenLogs/interactive-97_1.txt  &  interactive97="$interactive97 $!"  
wait $interactive97 
