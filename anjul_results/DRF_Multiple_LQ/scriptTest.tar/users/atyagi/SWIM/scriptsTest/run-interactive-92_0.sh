cd ~/ 
~/hadoop/bin/hadoop jar ~/hadoop/tez_jars/tez-examples-0.8.4.jar dumpjob  92 bursty0 >> ~/SWIM/scriptsTest/workGenLogs/interactive-92_0.txt 2>> ~/SWIM/scriptsTest/workGenLogs/interactive-92_0.txt  &  interactive92="$interactive92 $!"  
wait $interactive92 
