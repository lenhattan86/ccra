cd ~/ 
~/hadoop/bin/hadoop jar ~/hadoop/tez_jars/tez-examples-0.8.4.jar dumpjob  285 bursty2 >> ~/SWIM/scriptsTest/workGenLogs/interactive-85_2.txt 2>> ~/SWIM/scriptsTest/workGenLogs/interactive-85_2.txt  &  interactive85="$interactive85 $!"  
wait $interactive85 
