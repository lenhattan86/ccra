cd ~/ 
~/hadoop/bin/hadoop jar ~/hadoop/tez_jars/tez-examples-0.8.4.jar dumpjob  104 bursty1 >> ~/SWIM/scriptsTest/workGenLogs/interactive-4_1.txt 2>> ~/SWIM/scriptsTest/workGenLogs/interactive-4_1.txt  &  interactive4="$interactive4 $!"  
wait $interactive4 
