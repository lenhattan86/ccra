cd ~/ 
~/hadoop/bin/hadoop jar ~/hadoop/tez_jars/tez-examples-0.8.4.jar dumpjob  52 bursty0 >> ~/SWIM/scriptsTest/workGenLogs/interactive-52_0.txt 2>> ~/SWIM/scriptsTest/workGenLogs/interactive-52_0.txt  &  interactive52="$interactive52 $!"  
wait $interactive52 
