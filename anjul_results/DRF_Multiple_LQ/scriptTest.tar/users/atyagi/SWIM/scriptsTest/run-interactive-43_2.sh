cd ~/ 
~/hadoop/bin/hadoop jar ~/hadoop/tez_jars/tez-examples-0.8.4.jar dumpjob  243 bursty2 >> ~/SWIM/scriptsTest/workGenLogs/interactive-43_2.txt 2>> ~/SWIM/scriptsTest/workGenLogs/interactive-43_2.txt  &  interactive43="$interactive43 $!"  
wait $interactive43 
