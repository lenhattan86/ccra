cd ~/ 
~/hadoop/bin/hadoop jar ~/hadoop/tez_jars/tez-examples-0.8.4.jar dumpjob  56 bursty0 >> ~/SWIM/scriptsTest/workGenLogs/interactive-56_0.txt 2>> ~/SWIM/scriptsTest/workGenLogs/interactive-56_0.txt  &  interactive56="$interactive56 $!"  
wait $interactive56 
