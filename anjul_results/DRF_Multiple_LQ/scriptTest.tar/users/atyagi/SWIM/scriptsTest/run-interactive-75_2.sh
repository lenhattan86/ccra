cd ~/ 
~/hadoop/bin/hadoop jar ~/hadoop/tez_jars/tez-examples-0.8.4.jar dumpjob  275 bursty2 >> ~/SWIM/scriptsTest/workGenLogs/interactive-75_2.txt 2>> ~/SWIM/scriptsTest/workGenLogs/interactive-75_2.txt  &  interactive75="$interactive75 $!"  
wait $interactive75 
